<?php

namespace App\Models;

class DetectBanLog extends Model
{
    protected $connection = "default";
    protected $table = "detect_ban_log";
}
